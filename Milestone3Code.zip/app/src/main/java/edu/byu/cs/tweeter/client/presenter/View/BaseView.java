package edu.byu.cs.tweeter.client.presenter.View;

public interface BaseView {
    void displayErrorMessage(String message);
}
