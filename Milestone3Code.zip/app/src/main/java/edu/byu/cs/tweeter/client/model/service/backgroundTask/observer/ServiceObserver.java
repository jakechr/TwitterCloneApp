package edu.byu.cs.tweeter.client.model.service.backgroundTask.observer;

public interface ServiceObserver {
    void handleError(String message);
}
